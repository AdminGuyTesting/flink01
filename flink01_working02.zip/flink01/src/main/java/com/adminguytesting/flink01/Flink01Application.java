package com.adminguytesting.flink01;

import com.adminguytesting.flink01.FlinkSimpleTests.FlinkTest01;
import com.adminguytesting.flink01.FlinkSimpleTests.FlinkTest02;
import com.adminguytesting.flink01.FlinkSimpleTests.FlinkTest04;
import com.adminguytesting.flink01.FlinkSimpleTests.FlinkTest05;
import com.adminguytesting.flink01.FlinkSinkToFile.FlinkToFile02;
import com.adminguytesting.flink01.FlinkSinkToFile.FlinkToFile03;
import com.adminguytesting.flink01.FlinkSinkToFile.FlinkToFile04;
import org.apache.flink.api.common.functions.FlatMapFunction;
import org.apache.flink.api.common.state.MapState;
import org.apache.flink.api.common.state.MapStateDescriptor;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.DataStreamSink;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingProcessingTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.util.Collector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Flink01Application{

	private static final Logger log1 = LoggerFactory.getLogger(Flink01Application.class);
	public static void main(String[] args) throws Exception {

		System.out.println("lets start");
		log1.info("lets start with an info message");
		log1.warn("Lets fire a warning message");
		log1.error("Let s fire an error message");

		FlinkTest01 flinkTest01 = new FlinkTest01();
		FlinkTest02 flinkTest02 = new FlinkTest02();
		FlinkTest04 flinkTest04 = new FlinkTest04();
		FlinkTest05 flinkTest05 = new FlinkTest05();
		FlinkToFile02 flinkToFile02 = new FlinkToFile02();
		FlinkToFile03 flinkToFile03 = new FlinkToFile03();
		FlinkToFile04 flinkToFile04 = new FlinkToFile04();

		//flinkTest01.runTest02();
		//flinkTest02.runTest01();
		//flinkTest04.runTest1();

		//flinkTest05.runTest01();
		//flinkToFile03.runTest01();
		flinkToFile04.runTest01();

		System.out.println("Job finished");
		log1.info("Job finished");

	}

}