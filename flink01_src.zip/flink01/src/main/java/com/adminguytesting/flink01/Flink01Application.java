package com.adminguytesting.flink01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Flink01Application {

	public static void main(String[] args) {
		SpringApplication.run(Flink01Application.class, args);
	}

}
